# Kubernetes Setup Methods 


### Learning Setup: 
1. Minikube
1. Kind

### Producton Setup: 

1. kubeadm
1. kops ( Works for only AWS)
1. Kubespray


### Kubernetes As a Service

1. AKS - Azure Kubernetes Services
1. EKS - Elastic Kubernetes Service 
1. GKE - Google Kubernetes Engine 
