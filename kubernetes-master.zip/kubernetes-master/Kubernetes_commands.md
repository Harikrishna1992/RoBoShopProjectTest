# Common kubernetes Commands

kubectl version   
kubectl version --short   
kubectl cluster-info  
kubectl get pods -n kube-system  
kubectl get pods -n kube-system -o wide   
